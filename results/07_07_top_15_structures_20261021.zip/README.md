# Top 15 B7-H3 candidate structures — 2026-10-21 selection

Five ranked models per group: A_only, B_only and AB_pairs.
All structures are original AlphaFold 3 mmCIF (.cif) coordinates, retaining
antigen T and the candidate variable heavy/light chains. Open in ChimeraX,
PyMOL or another mmCIF-compatible molecular viewer.

Selection: each distinct input is ranked by its best native AF3 ranking score
among seeds101/202 and two samples per seed. One winning sample is included
per candidate. A-only and B-only lists considered40 and29 completed inputs;
AB considered170 of1160 planned inputs. AB ranking remains provisional.

Contents:15 coordinate CIFs, three source selection TSVs and a combined model
index with ranking scores, ipTM, pTM and chain identities. Model names retain
rank, input index and RF2 candidate lineage. Files are copied without conversion.

These are confidence-ranked computational complexes, not experimentally
validated binders or complete Fc-containing antibodies. Same-antigen dual-arm
engagement and interface/epitope acceptance require separate scientific QC.

Source: results/07_0{1,2,3}_fab_*/07_04_top_five_20261021/.
Report: reports/07_06_current_fab_inventory.md.
